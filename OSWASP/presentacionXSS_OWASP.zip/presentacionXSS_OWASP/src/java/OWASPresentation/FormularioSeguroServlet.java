package OWASPresentation;

import control.PersistenceManager;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Encoder;
import org.owasp.esapi.Validator;
import org.owasp.esapi.codecs.MySQLCodec;
import org.owasp.esapi.errors.IntrusionException;
import org.owasp.esapi.errors.ValidationException;

/**
 *
 * @author Juan Díez-Yanguas Barber
 */
public class FormularioSeguroServlet extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (validar(request) == true) {
            /////////////ESCAPAR ENTRADAS DE USUARIO///////////
//            String nombre = scapeUserEntries(request.getParameter("name"));
//            String telf = scapeUserEntries(request.getParameter("tlf"));
//            String email = scapeUserEntries(request.getParameter("email"));
//            String edad = scapeUserEntries(request.getParameter("edad"));

            ////////////SIN ESCAPAR ENTRADAS DE USUARIO///////////
            try{
            String nombre = request.getParameter("name");
            String telf = request.getParameter("tlf");
            String email = request.getParameter("email");
            String edad = request.getParameter("edad");

            nombre = validateName(nombre);
            telf = validateTelf(telf);
            email = validateEmail(email);
            int edadValidada = validateAge(edad);

            Item persona = new Item(nombre, telf, email, edadValidada);
            ((PersistenceManager) request.getServletContext().getAttribute("persistenceManager")).insertarRegistroInseguro(persona);

            }catch (IntrusionException ex){
                anadirError(request, ex.getUserMessage());
            }catch (ValidationException ex){
                anadirError(request, ex.getUserMessage());
            }catch (SQLException ex){
                Logger.getLogger(FormularioInseguroServlet.class.getName()).log(Level.SEVERE, "Error SQL", ex);
                anadirError(request, "Error SQL: " + ex.getMessage());
            }
        } else {
            anadirError(request, "El formulario recibido no tiene el formato esperado");
        }
        RequestDispatcher resultado = request.getRequestDispatcher("WEB-INF/resultado.jsp");
        resultado.forward(request, response);
    }

    protected boolean validar(HttpServletRequest request) throws ServletException, IOException {
        Map<String, String[]> parametrosPeticion = request.getParameterMap();

        if (parametrosPeticion.size() == 5
                && parametrosPeticion.containsKey("send_secure")
                && parametrosPeticion.containsKey("name")
                && parametrosPeticion.containsKey("tlf")
                && parametrosPeticion.containsKey("email")
                && parametrosPeticion.containsKey("edad")) {

            return true;
        } else {
            return false;
        }
    }

    protected String scapeUserEntries (String input){
        Encoder encod = ESAPI.encoder();
        return encod.encodeForSQL(new MySQLCodec(MySQLCodec.MYSQL_MODE), input);
    }

    protected String validateTelf (String input) throws IntrusionException, ValidationException{
        Validator validador = ESAPI.validator();
        return validador.getValidInput("Telefono", input, "Telf", 15, false);
    }

    protected int validateAge (String input) throws IntrusionException, ValidationException{
        Validator validador = ESAPI.validator();
        return validador.getValidInteger("Edad", input, 0, 170, false);
    }

    protected String validateName (String input) throws IntrusionException, ValidationException{
        Validator validador = ESAPI.validator();
        return validador.getValidInput("Nombre", input, "Name", 150, false);
    }

    protected String validateEmail (String input) throws IntrusionException, ValidationException{
        Validator validador = ESAPI.validator();
        return validador.getValidInput("Email", input, "Email", 150, true);
    }

    protected void anadirError(HttpServletRequest request, String error) {
        if (request.getAttribute("listaError") == null) {
            ArrayList<String> lista = new ArrayList<String>();
            lista.add(error);
            request.setAttribute("listaError", lista);
        } else {
            ArrayList<String> lista = (ArrayList<String>) request.getAttribute("listaError");
            lista.add(error);
            request.setAttribute("listaError", lista);
        }
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}

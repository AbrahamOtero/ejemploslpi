package OWASPresentation;

import control.PersistenceManager;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Juan Díez-Yanguas Barber
 */
public class FormularioInseguroServlet extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (this.validar(request, response) == false) {
            anadirError(request, "El formulario enviado no sigue el formato del formulario proporcionado");
        } else {
            String nombre = request.getParameter("name");
            String telf = request.getParameter("tlf");
            String email = request.getParameter("email");
            try {
                int edad = Integer.parseInt(request.getParameter("edad"));
                Item persona = new Item(nombre, telf, email, edad);
                ((PersistenceManager) request.getServletContext().getAttribute("persistenceManager")).insertarRegistroInseguro(persona);
            } catch (NumberFormatException ex) {
                anadirError(request, "La edad introducida no es válida");
            } catch (SQLException ex) {
                Logger.getLogger(FormularioInseguroServlet.class.getName()).log(Level.SEVERE, "Error SQL", ex);
                anadirError(request, "Error SQL: " + ex.getMessage());
            } finally {
                RequestDispatcher resultado = request.getRequestDispatcher("WEB-INF/resultado.jsp");
                resultado.forward(request, response);
            }
        }

    }

    protected boolean validar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Map<String, String[]> parametrosPeticion = request.getParameterMap();

        if (parametrosPeticion.size() == 5
                && parametrosPeticion.containsKey("send_insecure")
                && parametrosPeticion.containsKey("name")
                && parametrosPeticion.containsKey("tlf")
                && parametrosPeticion.containsKey("email")
                && parametrosPeticion.containsKey("edad")) {

            return true;
        } else {
            return false;
        }
    }

    protected void anadirError(HttpServletRequest request, String error) {
        if (request.getAttribute("listaError") == null) {
            ArrayList<String> lista = new ArrayList<String>();
            lista.add(error);
            request.setAttribute("listaError", lista);
        } else {
            ArrayList<String> lista = (ArrayList<String>) request.getAttribute("listaError");
            lista.add(error);
            request.setAttribute("listaError", lista);
        }
    }
        // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
        /**
         * Handles the HTTP <code>GET</code> method.
         * @param request servlet request
         * @param response servlet response
         * @throws ServletException if a servlet-specific error occurs
         * @throws IOException if an I/O error occurs
         */
        @Override
        protected void doGet


        (HttpServletRequest request, HttpServletResponse response)
        throws ServletException,
        IOException
        {
            processRequest(request, response);
        }
        /**
         * Handles the HTTP <code>POST</code> method.
         * @param request servlet request
         * @param response servlet response
         * @throws ServletException if a servlet-specific error occurs
         * @throws IOException if an I/O error occurs
         */
        @Override
        protected void doPost


        (HttpServletRequest request, HttpServletResponse response)
        throws ServletException,
        IOException
        {
            processRequest(request, response);
        }
        /**
         * Returns a short description of the servlet.
         * @return a String containing servlet description
         */
        @Override
        public String getServletInfo

             () {
        return "Short description";
        }// </editor-fold>

    }

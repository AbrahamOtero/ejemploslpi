package OWASPresentation;

/**
 *
 * @author JuanDYB
 */
public class Item {
    private String name;
    private String tlf;
    private String email;
    private int edad;

    public Item(String name, String tlf, String email, int edad) {
        this.name = name;
        this.tlf = tlf;
        this.email = email;
        this.edad = edad;
    }

    public int getEdad() {
        return edad;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public String getTlf() {
        return tlf;
    }

}

package control;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Web application lifecycle listener.
 * @author JuanDYB
 */
public class StartListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try {
            PersistenceManager persistencia = PersistenceManager.getPersistenceManager();
            persistencia.inicio();
            sce.getServletContext().setAttribute("persistenceManager", persistencia);
        } catch (NamingException ex) {
            Logger.getLogger(StartListener.class.getName()).log(Level.SEVERE, "No se encontro el recurso", ex);
            throw new RuntimeException("No se pudo iniciar la aplicación, no hay base de datos");
        }

    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        
    }
}

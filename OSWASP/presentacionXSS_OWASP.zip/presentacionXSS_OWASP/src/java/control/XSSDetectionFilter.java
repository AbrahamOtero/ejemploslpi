package control;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import org.owasp.esapi.ESAPI;
import org.owasp.esapi.Encoder;
import org.owasp.esapi.codecs.MySQLCodec;
import org.owasp.validator.html.AntiSamy;
import org.owasp.validator.html.CleanResults;
import org.owasp.validator.html.Policy;
import org.owasp.validator.html.PolicyException;
import org.owasp.validator.html.ScanException;

/**
 *
 * @author Juan Díez-Yanguas Barber
 */
public class XSSDetectionFilter implements Filter {


    /**
     *
     * @param request The servlet request we are processing
     * @param response The servlet response we are creating
     * @param chain The filter chain we are processing
     *
     * @exception IOException if an input/output error occurs
     * @exception ServletException if a servlet error occurs
     */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        request.setCharacterEncoding("UTF-8");
        try {
            if (this.secure(request) == false) {
                RequestDispatcher inseguro = request.getRequestDispatcher("WEB-INF/errorPageXSS.jsp");
                inseguro.forward(request, response);
            } else {
                chain.doFilter(request, response);
            }
        } catch (ScanException ex) {
            Logger.getLogger(XSSDetectionFilter.class.getName()).log(Level.SEVERE, "Error procesando formulario para XSS", ex);
        } catch (PolicyException ex) {
            Logger.getLogger(XSSDetectionFilter.class.getName()).log(Level.SEVERE, "Error procesando política de seguridad XSS", ex);
        }
    }

    private boolean secure (ServletRequest request) throws ScanException, PolicyException{
        Map <String, String []> parametros = request.getParameterMap();
        Set <String> keys = parametros.keySet();
        Iterator <String> iterador = keys.iterator();
        while (iterador.hasNext()){
            String [] lista = parametros.get(iterador.next());
            for (int i = 0; i < lista.length; i++){
                if (this.isStringSecure(lista[i], request) == false){
                    return false;
                }
            }
        }
        return true;
    }

    private boolean isStringSecure (String input, ServletRequest request) throws ScanException, PolicyException{
        
        Policy politica = Policy.getInstance(this.getClass().getResourceAsStream("/antisamy-slashdot-1.4.3.xml"));
        AntiSamy validator = new AntiSamy();
        CleanResults cr = validator.scan(ESAPI.encoder().canonicalize(input), politica);
        if (cr.getNumberOfErrors() == 0){
            return true;
        }else {
            request.setAttribute("clean", cr.getCleanHTML());
            request.setAttribute("error", cr.getErrorMessages());
            return false;
        }
    }

    protected void scapeUserEntries(ServletRequest request) {
        Map<String, String[]> parametrosPeticion = request.getParameterMap();
        Set<String> claves = parametrosPeticion.keySet();
        Iterator<String> iterador = claves.iterator();
        
        Encoder encod = ESAPI.encoder();

        while (iterador.hasNext()) {
            String clave = iterador.next();
            String[] lista = parametrosPeticion.get(clave);
            for (int i = 0; i < lista.length; i++) {
                lista [i] = encod.encodeForSQL(new MySQLCodec(MySQLCodec.MYSQL_MODE), lista[i]);
            }
            parametrosPeticion.remove(clave);
            parametrosPeticion.put(clave, lista);
        }
    }

    @Override
    public void init(FilterConfig fc) throws ServletException {
        
    }

    @Override
    public void destroy() {
        
    }
    
    /**
     * Return the filter configuration object for this filter.
     */
    

}

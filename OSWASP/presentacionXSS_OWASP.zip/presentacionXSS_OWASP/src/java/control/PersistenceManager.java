package control;

import OWASPresentation.Item;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @author JuanDYB
 */
public class PersistenceManager {

    private static PersistenceManager persistenceManager = null;
    private DataSource pool;

    PersistenceManager (){
        
    }

    public static PersistenceManager getPersistenceManager() {
        if (persistenceManager == null) {
            persistenceManager = new PersistenceManager();
        }
        return persistenceManager;
    }

    public void inicio() throws NamingException {
        Context env = (Context) new InitialContext().lookup("java:comp/env");
        pool = (DataSource) env.lookup("jdbc/HolaMundoPool");
    }

    public void insertarRegistroPrepared () throws SQLException{
        Connection conexion = pool.getConnection();
        PreparedStatement insert = conexion.prepareStatement("INSERT INTO PRESENTACION VALUES (?,?,?,?)");
    }

    public void insertarRegistroInseguro (Item pers) throws SQLException{
        Connection conexion = pool.getConnection();
        Statement insert = conexion.createStatement();
        insert.execute("INSERT INTO PRESENTACION VALUES ('" + pers.getName() + "', '" + pers.getTlf() + "', '" + pers.getEmail() + "', " + pers.getEdad() + ")");
        
        insert.close();
        conexion.close();
    }

    public ArrayList <String[]> consulta () throws SQLException{
        Connection conexion = pool.getConnection();
        PreparedStatement select = conexion.prepareStatement("SELECT * FROM PRESENTACION");
        ResultSet resultados = select.executeQuery();
        ArrayList <String []> devolver = new ArrayList<String []> ();
        while (resultados.next()){
            String [] fila = new String [4];
            fila [0] = resultados.getString("NAME");
            fila [1] = resultados.getString("TLF");
            fila [2] = resultados.getString("EMAIL");
            fila [3] = ((Integer)resultados.getInt("EDAD")).toString();
            devolver.add(fila);
        }
        return devolver;
    }
}
